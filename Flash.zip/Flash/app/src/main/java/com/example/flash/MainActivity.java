package com.example.flash;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.triggertrap.seekarc.SeekArc;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class MainActivity extends AppCompatActivity implements LocationListener, SensorEventListener {

    private SeekArc seekBar;
    private ImageView imageView;
    private ImageView imageView2;
    private ImageView imageView8;
    private ImageView imageView9;
    private int delay = 1000;
    private String stop = "0";
    private int i = 1;
    private Button button_Location;
    private TextView latitude;
    private TextView text_progress;
    private TextView longitude;
    private TextView blinker;
    private Vibrator vibration;
    private ImageView img_shd;
    private ImageView img_shd2;
    private ImageView compass_navigate;
    private View background_view;
    private MediaPlayer mediaPlayer;
    private ProgressBar progressBar;

    private List<Address> addresses = new ArrayList<>();
    private int vib_flash = 1;
    private int day_night = 1;
    private int sound = 1;
    private int main = 1;
    private int blink = 1;


    private final float[] mGravity = new float[3];
    private final float[] mGeomagnetic = new float[3];
    private float currentAzimuth = 0f;
    private SensorManager sensorManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView blinking = findViewById(R.id.torch);
        seekBar = findViewById(R.id.seek);
        ImageView flash_ON_Off = findViewById(R.id.button1);
        imageView = findViewById(R.id.imageView);
        imageView2 = findViewById(R.id.imageView2);
        button_Location = findViewById(R.id.location);
        latitude = findViewById(R.id.latitude);
        longitude = findViewById(R.id.longitude);
        blinker = findViewById(R.id.blinking);
        ImageView imageView3 = findViewById(R.id.sound);
        ImageView imageView4 = findViewById(R.id.vib);
        ImageView imageView6 = findViewById(R.id.mode);
        ImageView imageView7 = findViewById(R.id.share);
        ImageView imageView5 = findViewById(R.id.night);
        img_shd = findViewById(R.id.img_shd);
        img_shd2 = findViewById(R.id.img_shd2);
        background_view = findViewById(R.id.background_view);
        progressBar = findViewById(R.id.progressBar);
        imageView8 = findViewById(R.id.blue_torch);
        imageView9 = findViewById(R.id.blue1_torch);
        text_progress = findViewById(R.id.text_progress);
        compass_navigate = findViewById(R.id.compass_navigate);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);


        imageView5.setOnClickListener(new View.OnClickListener() {
            @TargetApi(Build.VERSION_CODES.M)
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View view) {
                if (day_night == 1) {
                    background_view.setAlpha(1f);
                    latitude.setTextColor(getColor(R.color.white));
                    longitude.setTextColor(getColor(R.color.white));
                    blinker.setTextColor(getColor(R.color.white));
                    compass_navigate.setColorFilter(getColor(R.color.white));

                    day_night++;
                } else {
                    background_view.setAlpha(0f);
                    latitude.setTextColor(getColor(R.color.black));
                    longitude.setTextColor(getColor(R.color.day_night));
                    blinker.setTextColor(getColor(R.color.day_night));
                    compass_navigate.setColorFilter(getColor(R.color.black));

                    day_night--;
                }
            }
        });

        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sound == 1) {
                    img_shd.setVisibility(View.VISIBLE);
                    mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.on_off);
                    mediaPlayer.start();
                    sound++;
                } else {
                    img_shd.setVisibility(View.INVISIBLE);
                    sound--;
                }
            }
        });

        imageView6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                startActivity(intent);
            }
        });

        imageView7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                String shareBody = "playStore.flash_trip";
                String shareSubject = "Your sub";

                intent.putExtra(Intent.EXTRA_TEXT, shareBody);
                intent.putExtra(Intent.EXTRA_SUBJECT, shareSubject);

                startActivity(Intent.createChooser(intent, "Share using"));

            }
        });


        if (ContextCompat.checkSelfPermission(getApplicationContext(),
                                              android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(getApplicationContext(),
                                                      android.Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(getApplicationContext(),
                                                     Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]
                    {Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.CAMERA}, 101);

        }

        button_Location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addresses.clear();
                button_Location.setText("");
                progressBar.setVisibility(View.VISIBLE);
                getLocation();
            }
        });

        flash_ON_Off.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View view) {
                if (main == 1) {
                    flashOn();
                    imageView.setVisibility(View.VISIBLE);
                    if (vib_flash != 1) {
                        vibration = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                        Objects.requireNonNull(vibration).vibrate(40);
                    }

                    if (sound != 1) {
                        mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.on_off);
                        mediaPlayer.start();
                    }
                    main++;
                } else {
                    flashOff();
                    imageView.setVisibility(View.INVISIBLE);
                    if (vib_flash != 1) {
                        vibration = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                        Objects.requireNonNull(vibration).vibrate(40);
                    }

                    if (sound != 1) {
                        mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.on_off);
                        mediaPlayer.start();
                    }
                    main--;
                }


            }
        });


        imageView4.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View view) {
                if (vib_flash == 1) {
                    vib_flash++;
                    img_shd2.setVisibility(View.VISIBLE);
                    vibration = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                    Objects.requireNonNull(vibration).vibrate(40);
                } else {
                    vib_flash--;
                    img_shd2.setVisibility(View.INVISIBLE);
                }

            }
        });

        blinking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (blink == 1) {
                    i = 1;
                    threadForSeek.start();
                    threadForLoop.start();
                    imageView2.setVisibility(View.VISIBLE);
                    imageView8.setVisibility(View.VISIBLE);
                    imageView9.setVisibility(View.VISIBLE);


                    blink++;

                } else {
                    blink--;
                    try {
                        i = -1000;
                        threadForSeek.stop();
                        threadForLoop.stop();
                    } catch (Exception ignored) {

                    }
                    imageView2.setVisibility(View.INVISIBLE);
                    imageView8.setVisibility(View.INVISIBLE);
                    imageView9.setVisibility(View.INVISIBLE);


                }

            }
        });
    }

    private void getLocation() {
        try {
            LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates
                    (LocationManager.NETWORK_PROVIDER, 5000, 5, this);

        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        try {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());

            addresses = geocoder.getFromLocation(location.getLatitude()
                    , location.getLongitude(), 1);

            String traced_actual_location = (addresses.get(0).getAddressLine(0));

            String traced_actual_latitude = String.valueOf(location.getLatitude());
            String traced_actual_longitude = String.valueOf(location.getLongitude());
            latitude.setText(traced_actual_latitude + "° N," + " " + traced_actual_longitude + "° E");

            button_Location.setText("");
            button_Location.setText(traced_actual_location);
            progressBar.setVisibility(View.INVISIBLE);


        } catch (Exception ignored) {

        }

    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {
    }

    @Override
    public void onProviderEnabled(String s) {
    }

    @Override
    public void onProviderDisabled(String s) {
        Toast.makeText(getApplicationContext()
                , "Please check your internet connection", Toast.LENGTH_SHORT).show();

    }

    class ThreadForLoopA extends Thread {
        @Override
        public void run() {
            seekBar.setOnSeekArcChangeListener(new SeekArc.OnSeekArcChangeListener() {
                @Override
                public void onProgressChanged(SeekArc seekArc, int progress, boolean b) {
                    int sliderValue;
                    sliderValue = progress;

                    if (sliderValue == 1) {
                        delay = 1000;
                    } else if (sliderValue <= 2) {
                        delay = 900;
                    } else if (sliderValue <= 3) {
                        delay = 850;
                    } else if (sliderValue <= 4) {
                        delay = 700;
                    } else if (sliderValue <= 5) {
                        delay = 600;
                    } else if (sliderValue <= 6) {
                        delay = 400;
                    } else if (sliderValue <= 7) {
                        delay = 300;
                    } else if (sliderValue <= 8) {
                        delay = 200;
                    } else if (sliderValue <= 9) {
                        delay = 100;
                    } else if (sliderValue <= 10) {
                        delay = 50;
                    }
                    text_progress.setText("" + (progress * 10) + "%");
                }


                @Override
                public void onStartTrackingTouch(SeekArc seekArc) {

                }

                @Override
                public void onStopTrackingTouch(SeekArc seekArc) {

                }
            });

        }
    }

    class ThreadForLoopB extends Thread {
        @TargetApi(Build.VERSION_CODES.M)
        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override
        public void run() {
            CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);

            while (i >= 1) {
                if (stop.equals("0")) {
                    stop = "1";
                    try {
                        String cameraID = Objects.requireNonNull(cameraManager).getCameraIdList()[0];
                        cameraManager.setTorchMode(cameraID, true);

                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                } else {
                    stop = "0";
                    try {
                        String cameraID = Objects.requireNonNull(cameraManager).getCameraIdList()[0];
                        cameraManager.setTorchMode(cameraID, false);
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException e) {
                    e.printStackTrace();

                }
                i++;

            }
            flashOff();

        }

    }


    private final ThreadForLoopA threadForSeek = new ThreadForLoopA();
    private final ThreadForLoopB threadForLoop = new ThreadForLoopB();

    @TargetApi(Build.VERSION_CODES.M)
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void flashOn() {
        CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            String cameraID = Objects.requireNonNull(cameraManager).getCameraIdList()[0];
            cameraManager.setTorchMode(cameraID, true);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    @TargetApi(Build.VERSION_CODES.M)
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void flashOff() {
        CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            String cameraID = Objects.requireNonNull(cameraManager).getCameraIdList()[0];
            cameraManager.setTorchMode(cameraID, false);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }


    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
                , SensorManager.SENSOR_DELAY_GAME);
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
                , SensorManager.SENSOR_DELAY_GAME);

    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        final float alpha = 0.97f;
        synchronized (this) {
            if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                mGravity[0] = alpha * mGravity[0] + (1 - alpha) * sensorEvent.values[0];
                mGravity[1] = alpha * mGravity[1] + (1 - alpha) * sensorEvent.values[1];
                mGravity[2] = alpha * mGravity[2] + (1 - alpha) * sensorEvent.values[2];
            }
            if (sensorEvent.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
                mGeomagnetic[0] = alpha * mGeomagnetic[0] + (1 - alpha) * sensorEvent.values[0];
                mGeomagnetic[1] = alpha * mGeomagnetic[1] + (1 - alpha) * sensorEvent.values[1];
                mGeomagnetic[2] = alpha * mGeomagnetic[2] + (1 - alpha) * sensorEvent.values[2];
            }
            float[] R = new float[9];
            float[] I = new float[9];
            boolean success = SensorManager.getRotationMatrix(R, I, mGravity, mGeomagnetic);
            if (success) {
                float[] orientation = new float[3];
                SensorManager.getOrientation(R, orientation);
                float azimuth = (float) Math.toDegrees(orientation[0]);
                azimuth = (azimuth + 360) % 360;

                Animation animation = new RotateAnimation
                        (-currentAzimuth, -azimuth, Animation.RELATIVE_TO_SELF
                                , 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);

                currentAzimuth = azimuth;

                animation.setDuration(500);
                animation.setRepeatCount(0);
                animation.setFillAfter(true);

                compass_navigate.startAnimation(animation);

            }

        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}